/** 
 *	@file conf_sncfg.h 
 */ 
#ifndef conf_sncfg_h
#define conf_sncfg_h

#ifndef LINUX
#define LINUX 1
#else
#undef LINUX
#define LINUX 1
#endif

#endif
