#ifndef __SNCFG_H__
#define __SNCFG_H__


/*******************************************************************************/
/* SNCFG definitions                                                           */
/*******************************************************************************/
#define MAXLEN_SNCFG_MSG 576


/*******************************************************************************/
/* SNCFG prototypes                                                            */
/*******************************************************************************/
enum {
	PRIVILEGE_LEVEL_ADMIN = 0,
	PRIVILEGE_LEVEL_GUEST,
	PRIVILEGE_LEVEL_POWERUSER,
	PRIVILEGE_LEVEL_UNKNOWN
};


/*******************************************************************************/
/* SNCFG variables                                                             */
/*******************************************************************************/


/*******************************************************************************/
/* SNCFG functions                                                             */
/*******************************************************************************/
extern int sncfg_get(char *key, char **value);
extern int sncfg_set(char *key, char *value);
extern int sncfg_commit(void);
extern int sncfg_reload(void);
extern int sncfg_reload_default(void);
extern int sncfg_restore_default(void);
extern int sncfg_backup_cfgfile(char *filename);
extern int sncfg_restore_cfgfile(char *filename);

/*
 * Plain Old Password
 */
extern int sncfg_update_password(char *id, char *old_password, char *new_password);

/*
 * Salted Old Password
 */
extern int sncfg_update_password2(char *id, char *old_password, char *new_password);

/*
 * Return 
 *   -1: Incorrect Name
 *    0: Admin 
 *    1: Guest 
 *    2: Power User
 */
extern int sncfg_update_username(char *old_name, char *new_name);

/*
 * Return 
 *   -1: Incorrect Name
 *    0: Admin
 *    1: Guest 
 *    2: Power User
 */
extern int sncfg_check_username(char *name);

/*
 * Return 
 *   -1: Incorrect ID
 *   -2: Incorrect Password
 *    0: Admin
 *    1: Guest 
 *    2: Power User
 */
extern int sncfg_check_passwd(char *id, char* password, int salted);

extern int sncfg_get_cpu_usage();
extern int sncfg_get_mem_usage();
extern int sncfg_get_uptime(int *uphours, int *upminutes, int *upseconds);
extern int sncfg_get_sys_time(char *sys_time);
extern int sncfg_get_sys_name(char *sys_name);
/*
 * type 0 : PPTPD
 * type 1 : L2TPD
 */
extern void sncfg_get_vpn_server_connection(char *string, int type);
/*
 * pptp :   key_index = PPTP_PROFILE_INDEX
 *          key_number = PPTP_NUMBER
 *          key_status = PPTP_STATUS
 *
 * l2tp :   key_index = L2TP_PROFILE_INDEX
 *          key_number = L2TP_NUMBER
 *          key_status = L2TP_STATUS
 *
 */
extern void sncfg_get_vpn_client_connection(char *string, char *key_index, 
    char *key_number, char *key_status);
extern int sncfg_system(const char *string);

/* ME_TYPE */
typedef enum {
	ME_SYS=0,
	ME_OMA=1,
	ME_CWMP=2,
	ME_CLI=3,
	ME_WEB=4,
	ME_DEFAULT=5
} ME_TYPE;
extern int sncfg_sc_set(char *key, char *value);
extern int sncfg_sc_get(char *key, char **value);
extern int sncfg_sc_get_uint(char* uri, unsigned int *result);
extern int sncfg_sc_get_int(char * uri, int * result);
extern int sncfg_sc_exe(char * uri, char **result);
extern int sncfg_sc_commit(void);
extern int sncfg_sc_reload(void);
extern int sncfg_sc_reload_default(void);
extern int sncfg_sc_restore_default(void);
extern int sncfg_sc_debug(char *key, char **value);
extern int sncfg_sc_test_me(char *key);
extern int sncfg_sc_test_get(void);
extern int sncfg_sc_test_set(void);
extern int sncfg_sc_get_tree_start(int type, int level, char *uri, int *treeid);
extern int sncfg_sc_get_tree_next(int type, char **uri, unsigned short *dtype, unsigned short *attr);
extern int sncfg_sc_get_dtype(char* uri, unsigned short *dtype);
extern int sncfg_sc_get_attr(char* uri, unsigned short *attr);
extern int sncfg_sc_get_limit(char * uri, char **limit);
extern int sncfg_sc_exe(char * uri, char **result);
extern int sncfg_sc_me_add_inst(char * uri, char * name, unsigned short *number);
extern int sncfg_sc_me_del_inst(char * uri);
extern int sncfg_sc_me_query_inst_number(char* uri,  unsigned short *number);
extern int sncfg_sc_query_inst_name(char* uri,	unsigned short number, char **value);
extern int sncfg_sc_query_last_name(char* uri,  char** name);
extern int sncfg_sc_query_inst_number(char* uri,  unsigned short *number);
extern int sncfg_sc_cb_set(char *key, char *value);
extern int sncfg_sc_cb_get(char *key, char **value);
extern int sncfg_sc_cb_get_int(char* uri, unsigned int *result);
extern int sncfg_sc_cb_get_uint(char* uri, unsigned int *result);
extern int sncfg_sc_cb_exe(char * uri, char **result);
extern int sncfg_sc_cb_me_add_inst(char * uri, char * name, unsigned short *number);
extern int sncfg_sc_cb_me_del_inst(char * uri);
extern int sncfg_cb_get(char *key, char **value);
extern int sncfg_cb_set(char *key, char *value);

//SC2.0 For Web integration
extern int sncfg_sc_get_instance_fields_by_num(char *url, unsigned short num, char* field[], char*value[], char **name);
extern int sncfg_sc_get_instance_fields(char *url, char* name, char* field[], char *value[]);
extern int sncfg_sc_add_instance_fields(char *url,  char* field[], char *value[], char **name);
extern int sncfg_sc_set_instance_fields(char *url, char* name, char*field[], char *value[]);
extern int sncfg_sc_del_instance_fields(char *url, char* name);

#ifdef WMX
extern int sncfg_wsrv_connection(int connect);
#endif
#ifdef DEBUG
extern int sncfg_dump(void);
#endif

#endif	// __SNCFG_H__
