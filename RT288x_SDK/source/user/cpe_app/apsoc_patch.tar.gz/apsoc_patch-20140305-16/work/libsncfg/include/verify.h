#ifndef __VERIFY_H__
#define __VERIFY_H__

/*******************************************************************************/
/* VERIFY definitions                                                         */
/*******************************************************************************/
#define IP_ADDR_PATTERN         "^[0-2]{0,1}[0-9]{1,2}\\.[0-2]{0,1}[0-9]{1,2}\\.[0-2]{0,1}[0-9]{1,2}\\.[0-2]{0,1}[0-9]{1,2}$"
#define NUMBER_PATTERN          "^[0-9]+(\\.[0-9]+)?$"
#define NORMAL_WORD_PATTERN     "^[A-Za-z0-9_]+$"
#define PASSWORD_PATTERN     	"^[A-Za-z0-9]+$"
#define MAC_ADDR_PATTERN        "^([0-9a-fA-F]{2}:){5}([0-9a-fA-F]){2}$"
#define TIME_PATTERN            "^([0-9]{2}:){2}([0-9]){2}$"   
#define DATE_PATTERN            "^([0-9]{2}-){2}([0-9]){4}$" 
#define URL_PATTERN             "^(([^:]+)://)?([^:/]+)(:([0-9]+))?(/.*)"
#define CIDR_ADDR_PATTERN       "^([0-2]{0,1}[0-9]{1,2}\\.[0-2]{0,1}[0-9]{1,2}\\.[0-2]{0,1}[0-9]{1,2}\\.[0-2]{0,1}[0-9]{1,2}|[0-2]{0,1}[0-9]{1,2}\\.[0-2]{0,1}[0-9]{1,2}\\.[0-2]{0,1}[0-9]{1,2}\\.[0-2]{0,1}[0-9]{1,2}\\/([0-9]{1,2})|[0-2]{0,1}[0-9]{1,2}\\.[0-2]{0,1}[0-9]{1,2}\\.[0-2]{0,1}[0-9]{1,2}\\.[0-2]{0,1}[0-9]{1,2}-[0-2]{0,1}[0-9]{1,2}\\.[0-2]{0,1}[0-9]{1,2}\\.[0-2]{0,1}[0-9]{1,2}\\.[0-2]{0,1}[0-9]{1,2})$"
#define USERNAME_PATTERN        "^[a-zA-Z0-9_]{3,16}$"
#define DOMAIN_NAME_PATTERN     "[^\\.\\/]+\\.[^\\.\\/]+$"
#define HEX_TEXT_PATTERN        "^[0-9a-fA-F]+$"
#define INTEGER_PATTERN         "^[0-9]+$"
#define ASCII_EXCLUDE_COMMA_PATTERN	"^[\x20-\x7e]+$"
#define DOMAIN_PATTERN		"^(([A-Za-z0-9][A-Za-z0-9\\-_]*)\\.)*([A-Za-z0-9][A-Za-z0-9\\-_]*)$"
//#define CIDR_ADDR_PATTERN       "^([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\/([0-9]{1,2})$"

typedef int verify_fun_t(char *, int, int);

/*******************************************************************************/
/* VERIFY prototypes                                                          */
/*******************************************************************************/


/*******************************************************************************/
/* VERIFY variables                                                           */
/*******************************************************************************/


/*******************************************************************************/
/* VERIFY functions                                                           */
/*******************************************************************************/
verify_fun_t verify_ip_address, verify_number, verify_range, verify_password, verify_username, 
    verify_netmask, verify_mac_address, verify_url, verify_cidr, verify_time, verify_date, verify_domain,
    verify_hex_text, verify_string_size, verify_normal_word, verify_integer, verify_positive_number, verify_ascii_exclude_comma, verify_portrange, verify_domain2;

#endif	// __VERIFY_H__
