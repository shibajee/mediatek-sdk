#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <stdarg.h>  
#include <syslog.h>
#include <signal.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h> 
#include <time.h>
#include <sys/sysinfo.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include "nvram_env.h"
#include "flash_api.h"
#include "nvram.h"
#include "nvram_env.h"

int sncfg_get(char *key, char **value)
{
	char *p = nvram_bufget(RT2860_NVRAM, key);
	if (p) {
		*value = strdup(p);
		return(0);
	} else {
		*value = NULL;
		return -1;
	}
}

int sncfg_set(char *key, char *value)
{
	nvram_bufset(RT2860_NVRAM, key, value);
	return(0);
}

int sncfg_commit(void)
{
	nvram_commit(RT2860_NVRAM);
	return(0);
}

int sncfg_nonblock_get(char *key, char **value)
{
	return(sncfg_get(key, value));
}

int sncfg_nonblock_set(char *key, char *value)
{
	return(sncfg_set(key, value));
}


int sncfg_reload(void)
{
	printf("%s:%d TODO...\n", __FUNCTION__, __LINE__);
	return 0;		
}

int sncfg_reload_default(void)
{
	printf("%s:%d TODO...\n", __FUNCTION__, __LINE__);
	return 0;		
}

int sncfg_restore_default(void)
{
	printf("%s:%d TODO...\n", __FUNCTION__, __LINE__);
	return 0;		
}

int sncfg_backup_cfgfile(char *filename)
{
	printf("%s:%d TODO...\n", __FUNCTION__, __LINE__);
	return 0;		
}

int sncfg_restore_cfgfile(char *filename)
{
	printf("%s:%d TODO...\n", __FUNCTION__, __LINE__);
	return 0;		
}

int sncfg_dset(char *key, char *value)
{
	printf("%s:%d TODO...\n", __FUNCTION__, __LINE__);
	return 0;
}

int sncfg_dunset(char *key)
{
	printf("%s:%d TODO...\n", __FUNCTION__, __LINE__);
	return 0;
}

int sncfg_chroot(char *path)
{
	printf("%s:%d TODO...\n", __FUNCTION__, __LINE__);
	return 0;		
}

int sncfg_get_uptime(int *uphours, int *upminutes, int *upseconds)
{
	struct sysinfo info;
	
	sysinfo(&info);
	*upminutes = (int)info.uptime / 60;
	*upseconds = (int)info.uptime % 60;
	*uphours = *upminutes / 60;
	*upminutes %= 60; 
	
	return 0;   
}

int sncfg_get_sys_time(char *sys_time)
{
	time_t t = time(NULL);
	    
    sprintf(sys_time,"%s",asctime(localtime(&t)));
    
    int i;
    for (i=0; i < strlen(sys_time); i++)
        if (sys_time[i] == '\n')
        {
            sys_time[i] = 0;
            break;
        }
            	    
    return 0;    
}

int sncfg_get_sys_name(char *sys_name)
{
    char* sysName = NULL;

    sncfg_get("SYS_NAME", &sysName);

    if(sysName){
        strcpy(sys_name, sysName);
        free(sysName);
    }else
        strcpy(sys_name, "WiMAX CPE Configuration Manager");

    return 0;
}

/*
 * Return 
 *   -1: Incorrect ID
 *   -2: Incorrect Password
 *    0: Guest 
 *    1: Admin
 *    2: Power User
 */
int sncfg_check_passwd(char *id, char *password, int salted)
{
	printf("%s:%d TODO...\n", __FUNCTION__, __LINE__);
	return 1;
}

/*
 * Return 
 *   -1: Incorrect Name
 *    0: Guest 
 *    1: Admin 
 *    2: Power User
 */
int sncfg_update_username(char *old_name, char *new_name)
{
	printf("%s:%d TODO...\n", __FUNCTION__, __LINE__);
	return 1;
}

int sncfg_get_cpu_usage()
{
	int u_sav, n_sav, s_sav, i_sav;
	int u, n, s, i;
	int du, dn, ds,di;
	int usage;
	FILE *fp;
	char buf[256];
	
	if (!(fp = fopen("/proc/stat", "r"))) { 	
 		return -1;
	}
	
	if (!fgets(buf, sizeof(buf), fp)) {
		fclose(fp);
		return -1;
	}
	usage = sscanf(buf, "cpu %u %u %u %u", &u_sav, &n_sav, &s_sav, &i_sav);
	if (usage < 4) {
		fclose(fp);
		return -1;
	}
	rewind(fp);
	fflush(fp);
	usleep(500000);
	if (!fgets(buf, sizeof(buf), fp)) {
		fclose(fp);
		return -1;
	}
	usage = sscanf(buf, "cpu %u %u %u %u", &u, &n, &s, &i);
	if (usage < 4) {
		fclose(fp);
		return -1;
	}
	du = u - u_sav; dn = n - n_sav; ds = s - s_sav; di = i - i_sav;
	usage = ((du + dn + ds) * 100) / (du + dn + ds + di);  
	
	fclose(fp);  
	
	return usage;  
}

int sncfg_get_mem_usage()
{
    int mtotal, mfree, mbuffer, musage;
    FILE *fp;
    char buf[256];
    
    if (!(fp = fopen("/proc/meminfo", "r"))) {
    	return -1;
    }
    if (fscanf(fp, "MemTotal: %u %s\n", &mtotal, buf) != 2) {
    	fclose(fp);
    	return -1;
    }
    if (fscanf(fp, "MemFree: %u %s\n", &mfree, buf) != 2) {
    	fclose(fp);
    	return -1;
    }
    if (fscanf(fp, "Buffers: %u %s\n", &mbuffer, buf) != 2) {
    	fclose(fp);
    	return -1;
    }	
    musage = ((mtotal - mfree - mbuffer) * 100) / mtotal;
    
    fclose(fp);    
    
    return musage;
}

/*
 * Plain Old Password
 */
int sncfg_update_password(char *id, char *old_password, char *new_password)
{
	printf("%s:%d TODO...\n", __FUNCTION__, __LINE__);
	return 0;
}

/*
 * Salted Old Password
 */
int sncfg_update_password2(char *id, char *old_password, char *new_password)
{
	printf("%s:%d TODO...\n", __FUNCTION__, __LINE__);
	return 0;
}

